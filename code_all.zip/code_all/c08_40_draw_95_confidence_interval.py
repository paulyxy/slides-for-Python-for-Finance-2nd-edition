# -*- coding: utf-8 -*-
"""
  Name     : c08_40_draw_95_confidence_interval.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import numpy as np
import scipy.stats as stats
import matplotlib.pyplot as plt

alpha=0.05   # significance level 
x=np.arange(-3,3,0.15)
y=stats.norm.pdf(x)
plt.plot(x,y)
#
z1=stats.norm.ppf(alpha)   
z2=stats.norm.ppf(1-alpha)   
plt.vlines(x=z1, ymin=-0., ymax=0.34, colors='green', ls=':', lw=2, label='vline_single - partial height')
plt.vlines(x=z2, ymin=-0., ymax=0.34, colors='green', ls=':', lw=2, label='vline_single - partial height')
plt.axhline(y = 0.25, xmin = 0.25, xmax = 0.75,linestyle="-",color="r") 
plt.figtext(0.4, 0.50, "95% confidence interval")
#
plt.title("Normal: probability density distribution")
plt.xlabel("Our X-values")
plt.ylabel("Density function")
plt.show()


