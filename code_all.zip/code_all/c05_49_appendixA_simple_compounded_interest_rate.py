# -*- coding: utf-8 -*-
"""
  Name     : c05_49_appendixA_simple_compounded_interest_rate.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import numpy as np
import matplotlib.pyplot as plt
pv=1000
r=0.08
n=10
t=np.linspace(0,n,n)
y1=np.ones(len(t))*pv # a horizontal line
y2=pv*(1+r*t)
y3=pv*(1+r)**t
plt.title('Simple vs. compounded interest rates')
plt.xlabel('Number of years')
plt.ylabel('Values')
plt.xlim(0,11)
plt.ylim(800,2200)
plt.plot(t, y1, 'b-')
plt.plot(t, y2, 'g--')
plt.plot(t, y3, 'r-')
plt.show()

