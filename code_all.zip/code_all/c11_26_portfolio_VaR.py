
"""
  Name     : c11_26_portfolio_VaR.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""
import numpy as np
import scipy as sp
import pandas as pd
import yfinance as yf
from scipy.stats import norm


# Step 1: input area
tickers=('IBM','WMT','C')  # tickers
begdate="2012-1-1"         # beginning date 
enddate="2016-12-31"       # ending date
weight=(0.2,0.5,0.3)       # weights
confidence_level=0.99      # confidence level 
position=5e6              # total value
#
z=norm.ppf(confidence_level) 
# Step 2: define a function
def ret_f(ticker,begdate,enddte):
    df=yf.download(ticker,begdate,enddate)
    ret=pd.DataFrame(df["Adj Close"].pct_change()).dropna()
    ret.columns=["ret_"+ticker]
    return(ret) 
# Step 3
final=ret_f(tickers[0],begdate,enddate)
for ticker in tickers[1:]:
    a=ret_f(ticker,begdate,enddate)
    final=final.merge(a,left_on=final.index,right_on=a.index)
    final.index=final["key_0"]
    del final["key_0"]
#
# Step 4: get porfolio returns
portRet=np.dot(final,weight)

portStd=portRet.std()
portMean=portRet.mean()
VaR=position*(portMean-z*portStd)
print("Holding=",position, "VaR=", round(VaR,2), "tomorrow")
# compare
total2=0.0
i=0
for ticker in tickers:
    ret=final["ret_"+ticker]
    position2=position*weight[i]
    i+=1
    mean=np.mean(ret)
    std=np.std(ret)
    VaR=position2*(mean-z*std)
    total2+=VaR
    print("For ", stock, "with a value of ", position2, "VaR=", round(VaR,2))
print("Sum of three VaR=",round(total2,2))

    
