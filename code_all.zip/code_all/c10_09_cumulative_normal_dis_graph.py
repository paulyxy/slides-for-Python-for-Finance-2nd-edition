"""
"""
  Name     : c10_09_cumulative_normal_dis_graph.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import numpy as np
import scipy as sp
import matplotlib.pyplot as plt
x = np.arange(-3,3,0.1)
y=sp.stats.norm.cdf(x)
plt.plot(x,y)
plt.show()
