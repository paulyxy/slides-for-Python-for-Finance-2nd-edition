# -*- coding: utf-8 -*-
"""
  Name     : c08_36_get_chickEgg_data.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import pandas as pd
infile="http://datayyy.com/data_csv/chickEgg.csv"
df=pd.read_csv(infile)
df.shape #Out[6]: (54, 2)
df.head()

   chicken   egg
0   468491  3581
1   449743  3532
2   436815  3327
3   444523  3255
4   433937  3156

df.to_pickle("c://temp/chickEgg.pickle")
