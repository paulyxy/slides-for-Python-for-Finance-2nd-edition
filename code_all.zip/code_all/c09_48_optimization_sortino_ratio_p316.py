"""
  Name     : c09_48_optimization_sortino_ratio_p316.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""
import scipy as sp   # p316
import numpy as np
import pandas as pd
from math import exp
import yfinance as yf
from scipy.optimize import fmin
#
ticker=('IBM','WMT','C') # tickers
begdate="2019-1-1"       # beginning date
enddate="2023-12-31"     # ending date
rf=0.0003                # annual risk-free rate

# function 1:
def ret_annual(ticker,begdate,enddte):
    df=yf.download(ticker,begdate,enddate)
    df["logret"]=np.lib.scimath.log(df["Adj Close"].pct_change()+1)
    df["year"]=df.index.year
    annualRet=np.exp(df.logret.groupby(df.year).sum())-1
    return(annualRet)

# function 2: estimate portfolio variance
def portfolio_var(R,w):
    cor = sp.corrcoef(R.T)
    std_dev=sp.std(R,axis=0)
    var = 0.0
    for i in np.arange(n):
        for j in np.arange(n):
            var += w[i]*w[j]*std_dev[i]*std_dev[j]*cor[i, j]
    return(var)

# function 2: estimate LPSD
def LPSD_f(returns, Rf):
    y=returns[returns-Rf<0]
    m=len(y)
    total=0.0
    for i in np.arange(m):
        total+=(y[i]-Rf)**2
    return(total/(m-1))

# function 3: estimate Sortino
def sortino(R,w):
    mean_return=np.mean(R,axis=0)
    ret = np.array(mean_return)
    LPSD=LPSD_f(R,rf)
    return(np.dot(w,ret) - rf)/LPSD

# function 4: for given n-1 weights, return a negative sharpe ratio
def negative_sortino_n_minus_1_stock(w):
    w2=np.append(w,1-sum(w))
    return (-sortino(R,w2)) # using a return matrix here!!!!!!

# Step 3: generate a return matrix (annul return)
n=len(ticker) # number of stocks
x2=ret_annual(ticker[0],begdate,enddate)
for i in np.arange(1,n):
    x_=ret_annual(ticker[i],begdate,enddate)
    x2=pd.merge(x2,x_,left_index=True,right_index=True)

# using scipy array format
R = np.array(x2)
print('Efficient porfolio (mean-variance) :ticker used')
print(ticker)

print('Sortino ratio for an equal-weighted portfolio')
equal_w=np.ones(n, dtype=float) * 1.0 /n
print(equal_w)
print(sortino(R,equal_w))

# for n stocks, we could only choose n-1 weights
w0= np.ones(n-1, dtype=float) * 1.0 /n
w1 = fmin(negative_sortino_n_minus_1_stock,w0)

final_w = np.append(w1, 1 - sum(w1))
final_sortino = sortino(R,final_w)
print ('Optimal weights are ')
print (final_w)
print ('final Sortino ratio is ')
print(final_sortino)
