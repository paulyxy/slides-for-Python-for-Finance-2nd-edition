"""
  Name     : c07_79_treynor_ratio_annual_freq.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""
import numpy as np
import pandas as pd
import yfinance as yf
ticker="ibm"
df=yf.download(ticker)
df['logRet']=np.log(df["Adj Close"].pct_change()+1)
df['year']=df.index.year
annualRet=np.exp(df["logRet"].groupby(df['year']).sum())-1
annualRet2=pd.DataFrame(annualRet)
annualRet2.columns=["annualRet"]  # change the column name

infile="http://datayyy.com/data_pickle/ff3annual.pkl"
ff3=pd.read_pickle(infile)

df2=annualRet2.merge(ff3,left_on=annualRet2.index,right_on=ff3.index,how="inner")

X = np.stack((df2.annualRet,df2.MKT_RF), axis=0)
cov=np.cov(X)
beta=cov[0,1]/cov[1,1]
beta=round(beta,5)
meanRet=round(df2.annualRet.mean(),5)
treynor =round((meanRet-meanRf)/beta,5)
#
print(f"ticker is {ticker}, mean={meanRet},beta={beta}, and meanRf={meanRf}")
print(f"Treynor Ratio of {ticker}={treynor}")


