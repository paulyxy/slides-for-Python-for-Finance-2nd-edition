
"""
  Name     : c11_22_VaR_500shares_WMT_sort_daily_expected_shartfall.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""
import numpy as np
import pandas as pd
import yfinance as yf
from scipy.stats import norm
#
ticker='WMT'            # input 1
n_shares=500            # input 2
confidence_level=0.99   # input 3
begdate="2012-1-1"       # input 4
enddate="2016-12-31"    # input 5
#
z=norm.ppf(1-confidence_level) 
df=yf.download(ticker,begdate,enddate)
df["ret"]=df["Adj Close"].pct_change()
ret2=np.sort(df.ret) 
#
position=round(n_shares*df.Close.iloc[-1] ,2)
n=ret2.shape[0]
m=int(n*(1-confidence_level))
print("m=",m)
#
sum=0.0
for i in np.arange(m):
    sum+=ret2[i]
ret3=sum/m
ES=position*ret3
print(f"Holding={position}, Expected Shortfall={round(ES,2)} tomorrow")









