# -*- coding: utf-8 -*-
"""
  Name     : c05_21_page174.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import p4f
r=0.182
g=0.03
d=[1.8,2.07,2.277,2.48193,2.68,2.7877]
final=p4f.pvValueNperiodModel(r,g,d)
#
print(final)


