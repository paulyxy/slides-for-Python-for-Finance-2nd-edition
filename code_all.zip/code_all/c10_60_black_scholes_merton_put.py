# -*- coding: utf-8 -*-
"""
  Name     : c10_60_black_scholes_merton_put.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

from scipy import stats
from math import log, exp, sqrt
#
def bs_put(S,X,T,r,sigma):
    d1=(log(S/X)+(r+sigma*sigma/2.)*T)/(sigma*sqrt(T))
    d2 = d1-sigma*sqrt(T)
    p=X*exp(-r*T)*stats.norm.cdf(-d2)-S*stats.norm.cdf(-d1)
    return(p)

bs_put(30,30,0.5,0.01,0.2)
