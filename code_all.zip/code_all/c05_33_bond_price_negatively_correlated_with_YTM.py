# -*- coding: utf-8 -*-
"""
  Name     : c05_33_bond_price_negatively_correlated_with_YTM.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import numpy_financial as npf

fv=1000
YTM=0.06
YTM=0.07
couponRate=0.08
n=10
freq=2
price=npf.pv(YTM/freq,n*freq,fv*couponRate/freq,fv)
