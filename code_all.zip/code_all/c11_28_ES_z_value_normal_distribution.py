"""
"""
  Name     : c11_28_ES_z_value_normal_distribution.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import numpy as np
#
np.random.seed(12345) 
n=5000000
ret=np.random.normal(0,1,n) 
print(ret[0:5] )


