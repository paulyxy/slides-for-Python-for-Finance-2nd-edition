# -*- coding: utf-8 -*-
"""
  Name     : c11_36_volatility_2stock_2_stock_portfolio_example_sumulation.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""
# volatility of two-stock portfolio
import math
import numpy as np
from scipy import stats
from numpy import random
#
def portfolio_vol_2stocks(ret1,ret2,w1):
     x1=w1
     x2=1-x1
     s1=ret1.std()
     s2=ret2.std()
     t1=x1**2*s1**2
     t2=x2**2*s2**2
     v=t1+t2+2*x1*x2*np.cov(ret1,ret2)[1,1]
     return(math.sqrt(v))
#
np.random.seed(12345)
n=50_000
m1=0.02
m2=0.05
std1_0=0.2
std2_0=0.12
ret1= random.normal(m1,std1_0,n)    
ret2= random.normal(m2,std2_0,n)    
w1=0.4
std1=round(ret1.std(),6)
std2=round(ret2.std(),6)
v=round(portfolio_vol_2stocks(ret1,ret2,w1),6)
print(f"vol of a 2-stock port ={v}, w1={w1}")
print(f"std1 = {std1}, std2={std2}")







  
