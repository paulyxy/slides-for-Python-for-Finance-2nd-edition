# -*- coding: utf-8 -*-
"""
  Name     : c08_01_normal_distribution.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import numpy as np
import scipy.stats as stats
import matplotlib.pyplot as plt
x=np.arange(-3,3,0.15)
y=stats.norm.pdf(x)
plt.plot(x,y)
plt.title("Normal: probability density distribution")
plt.xlabel("Our X-values")
plt.ylabel("Density function")
plot.show()




import numpy as np
import scipy.stats as stats
import matplotlib.pyplot as plt
x=np.arange(-3,3,0.15)
y=stats.norm.cdf(x)
plt.plot(x,y)
plt.title("Normal Density probability distribution")
plt.xlabel("Our X-values")
plt.ylabel("Density function")
plot.show()
