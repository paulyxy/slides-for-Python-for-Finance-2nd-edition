# -*- coding: utf-8 -*-
"""
  Name     : c01_15_if_condition.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

r=-0.05

if(r<0):
    print("interest rate is less than zero")
