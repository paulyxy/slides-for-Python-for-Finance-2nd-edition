"""
"""
  Name     : c05_29_import_p4f.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import sys
from download import download
a=sys.version[0:3]
path="http://datayyy.com/code_py/"
#
if a=="3.7":
    file="p4f37.pyc"    
elif a=="3.8":
    file="p4f38.pyc"    
elif a=="3.9":
    file="p4f39.pyc"
else:
    print('Version issue')
#
infile=path+file
outfile='p4f.pyc'
download(infile,outfile,replace=True)
import p4f
print(dir(p4f))





