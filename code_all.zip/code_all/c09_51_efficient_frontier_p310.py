# -*- coding: utf-8 -*-
"""
  Name     : c09_51_efficient_frontier_p310.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import numpy as np
import pandas as pd
import scipy as sp
import yfinance as yf
import matplotlib.pyplot as plt
from numpy.linalg import inv, pinv
#
begYear,endYear = 2001,2013
begdate=str(begYear)+"-1-1"
enddate=str(endYear)+"-12-31"
stocks=['IBM','WMT','AAPL','C','MSFT']

def ret_monthly(ticker):   # function 1
    df =yf.download(ticker,begdate,enddate)
    df["logret"]=np.log(df["Adj Close"].pct_change()+1) 
    df["yyyymm"]=df.index.year*100+df.index.month
    retM=np.exp(df.logret.groupby(df.yyyymm).sum())-1
    retM=pd.DataFrame(retM)
    retM.columns=["retM"]
    return(retM)

def objFunction(W, R, target_ret):  # function 2: objective function 
    stock_mean=np.mean(R,axis=0) 
    port_mean=np.dot(W,stock_mean) # portfolio mean 
    cov=np.cov(R.T) # var-cov matrix
    port_var=np.dot(np.dot(W,cov),W.T) # portfolio variance 
    penalty = 2000*abs(port_mean-target_ret)# penalty 4 deviation 
    obj=np.sqrt(port_var) + penalty # objective function
    return(obj) 

R0=ret_monthly(stocks[0]) # starting from 1st 
R0.columns=[stocks[0]]

for stock in stocks[1:]:   # merge with other stocks 
    x=ret_monthly(stock) 
    x.columns=[stock]
    R0=R0.merge(x,left_on=R0.index,right_on=x.index)
    R0.index=R0["key_0"]
    del R0["key_0"]
# ValueError: Unable to fill values because RangeIndex cannot contain NA

out_mean,out_std,out_weight=[],[],[] 
stockMean=np.mean(R0,axis=0)
n_stock=len(tickers)
for r in np.linspace(np.min(stockMean),np.max(stockMean),num=100):
    W = np.ones([n_stock])/n_stock # starting from equal weights 
    b_ = [(0,1)]
    for i in range(n_stock):
        # bounds, here no short 
        c_ = ({'type':'eq', 'fun': lambda W: sum(W)-1. })#constraint
        result=sp.optimize.minimize(objFunction,W,(R0,r),method='SLSQP',constraints=c_, bounds=b_)
        
        
        
        
        

 
 
 if not result.success: # handle error raise 

               
               
               
