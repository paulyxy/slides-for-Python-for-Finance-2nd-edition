# -*- coding: utf-8 -*-
"""
  Name     : c09_60_errata_p301.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

#Errata p301


import pandas as pd
import yfinance as yf
tickers=['IBM','dell','wmt']



path1='http://chart.yahoo.com/table.csv?s=^GSPC'
final=pd.read_csv(path1,usecols=[0,6],index_col=0)
final.columns=['^GSPC']
path2='http://chart.yahoo.com/table.csv?s=ttt'
for ticker in tickers:
print ticker
x = pd.read_csv(path2.replace('ttt',ticker),usecols=[0,6],index_
col=0)
x.columns=[ticker]
final=pd.merge(final,x,left_index=True,right_index=True)
