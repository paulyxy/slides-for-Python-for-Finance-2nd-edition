# -*- coding: utf-8 -*-
"""
  Name     : c04_10_from_daily_ret_to_monthly_ret.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import pandas as pd
import yfinance as yf
from math import exp,log
#
ticker='IBM'
begdate="2015-1-1"
enddate="2015-12-31"
df = yf.download(ticker, begdate, enddate)
#
aa=pd.DataFrame(df["Adj Close"].pct_change().dropna()+1)
aa["yyyymm"]=aa.index.year*100+aa.index.month
aa.columns=["retPlus1","yyyymm"]
retMonthly=aa.retPlus1.groupby(aa.yyyymm).prod()-1
retMonthly.head()





