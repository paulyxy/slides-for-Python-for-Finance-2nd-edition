# -*- coding: utf-8 -*-
"""
  Name     : c06_47_homework_debug_merge.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import pandas as pd
import yfinance as yf
ibm=yf.download("WMT")
infile="http://datayyy.com/data_pickle/ff3Daily.pickle"
ff3=pd.read_pickle(infile)

ibm.head()
ff3.head()
df=ibm.merge(ff3,left_on=ibm.index,right_on=ff3.index)
