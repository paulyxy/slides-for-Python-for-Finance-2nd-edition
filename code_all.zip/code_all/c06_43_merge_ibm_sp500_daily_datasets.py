# -*- coding: utf-8 -*-
"""
  Name     : c06_43_merge_ibm_sp500_daily_datasets.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""
import pandas as pd
import yfinance as yf
ibm=yf.download("IBM")
sp500=yf.download("^GSPC")


ibm["ret"]=ibm["Close"].pct_change()
sp500["mktRet"]=sp500["Adj Close"].pct_change()
df=pd.merge(ibm,sp500,left_on=ibm.index,right_on=sp500.index)
pd.set_option('display.max_columns',None)  


 
