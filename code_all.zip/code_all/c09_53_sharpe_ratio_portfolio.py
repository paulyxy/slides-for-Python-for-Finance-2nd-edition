"""
  Name     : c09_53_sharpe_ratio_portfolio.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""
import numpy as np   # p308
import scipy as sp
import pandas as pd
import yfinance as yf
from scipy.optimize import fmin
#1. Code for input area:
tickers=('IBM','WMT','C')  # tickers
begdate="1990-1-1"        # beginning date
enddate="2012-12-31"      # ending date
rf=0.0003                 # annual risk-free rate
def ret_annual(ticker,begdate,enddate):
    df=yf.download(ticker,begdate,enddate)
    df["logret"] =np.log(df["Adj Close"].pct_change()+1)
    df["year"]=df.index.year
    retAnnual=np.exp(df.logret.groupby(df.year).sum())-1
    retAnnual=pd.DataFrame(retAnnual)
    retAnnual.columns=["ret_"+ticker]
    return(retAnnual)
# function 2: estimate portfolio variance
def portfolio_var(R,w):
    cor = np.corrcoef(R.T)
    std_dev=np.std(R,axis=0)
    var = 0.0
    for i in np.arange(n):
        for j in np.arange(n):
            #print(i,j)
            var += w[i]*w[j]*std_dev[i]*std_dev[j]*cor[i, j]
    return(var)
# function 3: estimate Sharpe ratio
def sharpeRatio(R,w):
    var = portfolio_var(R,w)
    mean_return=np.mean(R,axis=0)
    ret = np.array(mean_return)
    return (np.dot(w,ret) - rf)/np.sqrt(var)
# function 4:given n-1 weights, return a negative sharpe ratio
def negative_sharpe_n_minus_1_stock(w):
    w2=np.append(w,1-sum(w))
    return(-sharpeRatio(R,w2)) # using a return matrix here!!!!!!
#
x2=ret_annual(tickers[0],begdate,enddate)
for ticker in tickers[1:]:
    x_=ret_annual(ticker,begdate,enddate)
    x2=x2.merge(x_,left_on=x2.index,right_on=x_.index)
    x2.index=x2["key_0"]
    del x2["key_0"]
  
# using scipy array format
R = np.array(x2)
print(f"Efficient porfolio (mean-variance) :tickers used {tickers}")
print('Sharpe ratio for an equal-weighted portfolio')
equal_w=np.ones(n, dtype=float) * 1.0 /n
print(equal_w)
print(f"Sharpe Ratio with equal mean={sharpeRatio(R,equal_w)}")
# for n stocks, we could only choose n-1 weights
w0= np.ones(n-1, dtype=float) * 1.0 /n
w1 = fmin(negative_sharpe_n_minus_1_stock,w0) #optimize
optimal_w = np.append(w1, 1 - sum(w1))
optimal_sharpeRatio= sharpeRatio(R,optimal_w)
#
print (f"Optimal weights are {optimal_w}")
print (f"Final Sharpe ratio is {optimal_sharpeRatio}")





