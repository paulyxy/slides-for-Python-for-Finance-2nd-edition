# -*- coding: utf-8 -*-
"""
  Name     : c06_46_WMT_using_ff3daily.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import pandas as pd
import yfinance as yf
import statsmodels.api as sm
ibm=yf.download("WMT")
ibm["ret"]=ibm["Close"].pct_change()
ff3=pd.read_pickle('c://temp/ff3daily.pkl')
df=ibm.merge(ff3,left_on=ibm.index,right_on=ff3.index)
df=df.dropna()
y=df["ret"]-df["RF"]
x=df["MKT_RF"]
x=sm.add_constant(x)
results=sm.OLS(y,x).fit()
print(results.summary())
