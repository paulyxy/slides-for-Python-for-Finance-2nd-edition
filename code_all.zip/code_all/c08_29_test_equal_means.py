# -*- coding: utf-8 -*-
"""
  Name     : c08_29_test_equal_means.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""
import numpy as np
import pandas as pd
import scipy.stats as stats

infile="http://datayyy.com/data_csv/sleep.csv"
df=pd.read_csv(infile)
#
group1=df[df.group==1]
group2=df[df.group==2]

group1.extra.mean()  # Out[200]: 0.75
group2.extra.mean()  # Out[201]: 2.3299999999999996

stats.ttest_ind(a=group1.extra, b=group2.extra, equal_var=True)
stats.ttest_ind(a=group1.extra, b=group2.extra, equal_var=False)


