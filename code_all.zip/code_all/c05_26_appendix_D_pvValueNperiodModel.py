# -*- coding: utf-8 -*-
"""
  Name     : c05_26_appendix_D_pvValueNperiodModel.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

def pvValueNperiodModel(r,longTermGrowthRate,dividendNplus1):
    """Objective: estimate stock price based on an n-period model
                    r: discount rate
    LongTermGrowhRate: long term dividend growth rate
      dividendsNpus1 : a dividend vector n + 1
 
    PV = d1/(1+R) + d2/(1+R)**2 + .... + dn/(1+R)**n +
    
    sellingPrice/(1+R)**n
    sellingPrice= d(n+1)/(r-g)
    
    where g is long term growth rate
    
    Example #1:>>> r=0.182
               >>> g=0.03
               >>> d=[1.8,2.07,2.277,2.48193,2.68,2.7877]
               >>>pvValueNperiodModel(r,g,d)
                   17.472364312825711
    """
    import numpy_financial as npf
    d=dividendNplus1
    n=len(d)-1
    g=longTermGrowthRate
    pv=npf.npv(r,d[:-1])*(1+r)
    sellingPrice=d[n]/(r-g)
    pv+=npf.pv(r,n,0,-sellingPrice)
    return(pv)
    
