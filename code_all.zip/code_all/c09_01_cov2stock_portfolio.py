# -*- coding: utf-8 -*-
"""
  Name     : c09_01_cov2stock_portfolio.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

def var2stock(wA,varA,varB,covAB):
    wB=1-wA
    var=wA**2*varA+wB**2*varB**2+2*wA*wB*covAB
    return(var)
    
    
    
