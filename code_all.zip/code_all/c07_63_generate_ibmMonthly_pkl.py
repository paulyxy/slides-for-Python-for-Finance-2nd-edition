# -*- coding: utf-8 -*-
"""
  Name     : c07_63_generate_ibmMonthly_pkl.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

pv=100
fv=pv*(1+0.1)**20

print(fv)
