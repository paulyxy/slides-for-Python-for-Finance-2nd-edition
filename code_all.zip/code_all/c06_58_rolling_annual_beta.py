# -*- coding: utf-8 -*-
"""
  Name     : c06_58_rolling_annual_beta.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import numpy as np
import pandas as pd
import yfinance as yf
import statsmodels.api as sm
ibm=yf.download("IBM")
sp500=yf.download("^GSPC")
ibm["ret"]=ibm["Close"].pct_change()
ibm["year"]=ibm.index.year

sp500["mktRet"]=sp500["Adj Close"].pct_change()
df=ibm.merge(sp500,left_on=ibm.index,right_on=sp500.index)
df=df.dropna()
#pd.set_option('display.max_columns',None)   

years=np.unique(df.year)

betas=[]
for year in years:
    df2=df[df.year==year]
    y=df2["ret"]
    x=df2["mktRet"]
    x=sm.add_constant(x)
    results=sm.OLS(y,x).fit()
    beta=round(results.params[1],3)
    betas.append(beta)
#
annualBetas=pd.DataFrame([years,betas]).T
annualBetas.columns=["year","beta"]
    
    
    
