"""
  Name     : c09_56_errata_p318.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""
# errata p318
import numpy as np
import pandas as pd
import yfinance as yf
#
begdate="2012-1-1"
enddate="2016-12-31"
ticker='IBM'
#
def ret_f(ticker,begdate,enddte):
    df=yf.download(ticker, begdate,enddate)
    ret =pd.DataFrame(df["Adj Close"].pct_change().dropna())
    name=ticker+"_ret"
    ret.columns=[name]
    return(ret)
#
a=ret_f(ticker,begdate,enddate)
b=ret_f("^GSPC",begdate,enddate)
a=a.merge(b,left_on=a.index,right_on=b.index)

print(a.head())
mean=a.mean()
print(mean[1:])
del a["key_0"]
cov=np.dot(a.T,a)
print(cov)
#
