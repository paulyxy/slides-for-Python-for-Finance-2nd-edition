# -*- coding: utf-8 -*-
"""
  Name     : c08_26_test_for_equal_varince.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import scipy.stats as stats
# Test whether the lists `a`, `b` and `c` come from populations  with equal variances.
a = [8.88, 9.12, 9.04, 8.98, 9.00, 9.08, 9.01, 8.85, 9.06, 8.99]
b = [8.88, 8.95, 9.29, 9.44, 9.15, 9.58, 8.36, 9.18, 8.67, 9.05]
c = [8.95, 9.12, 8.95, 8.85, 9.03, 8.84, 9.07, 8.98, 8.86, 8.98]
stat, p = stats.levene(a, b, c)
print(f"p-value = {p}")
# The small p-value suggests that the populations do not have equal variances.

