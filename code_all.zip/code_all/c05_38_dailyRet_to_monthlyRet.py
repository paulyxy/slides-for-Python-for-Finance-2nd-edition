# -*- coding: utf-8 -*-
"""
  Name     : c05_38_dailyRet_to_monthlyRet.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""


import yfinance as yf
import numpy as np
df=yf.download("ibm")
df['logRet']=np.log(df["Adj Close"].pct_change()+1)
df['YYYYMM']=df.index.year*100+df.index.month
monthlyRet=np.exp(df["logRet"].groupby(df['YYYYMM']).sum())-1

monthlyRet.head()


