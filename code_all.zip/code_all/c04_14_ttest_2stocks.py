# -*- coding: utf-8 -*-
"""
  Name     : c04_16_ttest_2stocks.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""


import yfinance as yf
import scipy.stats as stats

begdate="2013-1-1"
enddate="2016-12-9"

def ret_f(ticker,begdate,enddate):
     df= yf.download(ticker,begdate, enddate)
     ret=df["Adj Close"].pct_change().dropna()
     return(ret)
     
a=ret_f('IBM',begdate,enddate)
b=ret_f('MSFT',begdate,enddate)
print(stats.ttest_ind(a,b))

