# -*- coding: utf-8 -*-
"""
  Name     : c04_06_read_local_csv_file.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import pandas as pd

df=pd.read_csv("c:/temp/ibm.csv")

print(df.head())
