# -*- coding: utf-8 -*-
"""
  Name     : c3_04_appendixE.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017, 3/19, 2024
  email    : paulyxy@gmail.com
"""

import numpy_financial as npf
import matplotlib.pyplot as plt

#
cashflows=[-100,50,60,70]
rate=[]
npv=[]
#
for i in range(1,70):
    rate.append(0.01*i)
    npv.append(npf.npv(0.01*i,cashflows))
    
#  
plt.title("NPV profile (2024)")
plt.xlabel("Discount Rate")
plt.ylabel("NPV (Net Present Value)")
plt.hlines(0,0,0.7,colors="red")
plt.plot(rate,npv)
plt.show()


