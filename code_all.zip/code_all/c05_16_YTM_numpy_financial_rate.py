# -*- coding: utf-8 -*-
"""
  Name     : c05_16_YTM_numpy_financial_rate.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import numpy_financial as npf
rate=npf.rate(5,0.03*1000,-818,1000)
print(rate)

