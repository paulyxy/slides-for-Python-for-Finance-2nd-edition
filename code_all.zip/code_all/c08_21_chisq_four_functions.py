# -*- coding: utf-8 -*-
"""
  Name     : c08_21_chisq_four_functions.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import numpy as np
import scipy.stats as stats

stats.chi.pdf(x,df)
stats.chi.cdf(x,df)
stats.chi.ppf(x,df)

df=4
n=10
np.random.chisquare(df,n)


