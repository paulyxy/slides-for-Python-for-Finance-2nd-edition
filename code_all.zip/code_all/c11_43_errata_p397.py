# -*- coding: utf-8 -*-
"""
  Name     : c11_43_errata_p397.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import numpy as np
import pandas as pd
import yfinance as yf
from scipy.stats import norm

#
# input area
ticker='IBM' # input 1
n_shares=1000 # input 2
confidence_level=0.99 # input 3
begdate="2012-2-7" # input 4
enddate="2017-2-7" # input 5
z=norm.ppf(1-confidence_level) 
df=yf.download(ticker,begdate,enddate)
ret = df["Adj Close"].pct_change()
position=round(n_shares*df.Close.iloc[-1],2)
std=ret.std()
VaR=round(position*z*std,2)
print(f"Holding={position} VaR={VaR} tomorrow")
