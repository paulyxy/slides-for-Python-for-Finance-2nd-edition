# generate ff_monthly.pickle   

"""
  Name     : c04_18_federal_fund_rate.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import numpy as np
import pandas as pd
#
infile="http://datayyy.com/data_csv/DFF.csv"
df=pd.read_csv(infile)

dd=rate=[]
n=len(df)
y=np.array(df)
rate=[]

for i in np.arange(n):
    t=y[i][0]
    dd.append(pd.to_datetime(t, format='%Y-%m-%d').date())
    rate.append(y[i][1]/100.)
#
fedFundRate=pd.DataFrame(rate,index=dd,columns=['FEDFUNDRATE'])
fedFundRate.to_pickle("c:/temp/fedFundRate.pkl")    


