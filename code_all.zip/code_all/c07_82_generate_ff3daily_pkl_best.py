"""
  Name     : c07_82_generate_ff3daily_pkl_best.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import pandas as pd
import datetime
df=pd.read_csv("c://temp/ff3daily.csv",skiprows=5,header=None)
df.columns=["Date","MKT_RF","SMB","HML","RF"]
df['Date2'] = pd.to_datetime(df['Date'],format="%Y%m%d")
df = df.set_index(pd.DatetimeIndex(df["Date2"]))
#
df = df.drop(['Date','Date2'], axis=1)
df=df/100
df.to_pickle("c://temp/ff3daily.pkl")
