# -*- coding: utf-8 -*-
"""
  Name     : c06_54_not_working.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import numpy as np
from dataset import Dataset
import matplotlib.pyplot as plt
infile="https://www2.cs.arizona.edu/classes/cs120/fall17/ASSIGNMENTS/assg02/Pokemon.csv"
pokemon = Dataset(infile, delimiter=',', header=0)
