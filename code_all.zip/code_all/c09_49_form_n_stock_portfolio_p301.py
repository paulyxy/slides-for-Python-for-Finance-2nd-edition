# -*- coding: utf-8 -*-
"""
  Name     : c09_49_form_n_stock_portfolio_p301.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import pandas as pd
import yfinance as yf
#
tickers=['IBM','dell','wmt',"^GSPC"]
final=yf.download(tickers[0])
final.columns=tickers[0]+"_"+final.columns
#
for ticker in tickers[1:]:
    df=yf.download(ticker)
    df.columns=ticker+"_"+df.columns
    print(ticker)
    final=final.merge(df,left_on=final.index,right_on=df.index)
    final.index=final["key_0"]
    del final["key_0"]

 pd.set_option('display.max_columns',None)    
 print(final.head())
