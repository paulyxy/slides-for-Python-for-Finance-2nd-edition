"""
  Name     : c10_63_delta_tiny_number.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

from scipy import stats
from math import log,exp,sqrt
#
tiny=1e-9
S=40
X=40
T=0.5
r=0.01
sigma=0.2
#
def bsCall(S,X,T,r,sigma):
    d1=(log(S/X)+(r+sigma*sigma/2.)*T)/(sigma*sqrt(T))
    d2 = d1-sigma*sqrt(T)
    c=S*stats.norm.cdf(d1)-X*exp(-r*T)*stats.norm.cdf(d2)
    return(c) 

def delta1_f(S,X,T,r,sigma):
    d1=(log(S/X)+(r+sigma*sigma/2.)*T)/(sigma*sqrt(T))
    delta=stats.norm.cdf(d1)
    return(delta) 
#
def delta2_f(S,X,T,r,sigma):
    s1=S
    s2=S+tiny
    c1=bsCall(s1,X,T,r,sigma)
    c2=bsCall(s2,X,T,r,sigma)
    delta=(c2-c1)/(s2-s1)
    return(delta)
#
delta1=round(delta1_f(S,X,T,r,sigma),6)
delta2=round(delta2_f(S,X,T,r,sigma),6)
print(f"delta (close form)={delta1}")
print(f"delta (tiny number)={delta2}")



