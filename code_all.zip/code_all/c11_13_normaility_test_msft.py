"""
"""
  Name     : c11_13_normaility_test_msft.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import numpy as np 
import pandas as pd
import yfinance as yf
from scipy import stats 

#
ticker='MSFT' 
begdate="2012-1-1" 
enddate="2016-12-31" 
#
df=yf.download(ticker, begdate, enddate) 
ret = pd.DataFrame(df["Adj Close"].pct_change()).dropna()
ret.columns=["ret"]
#
print('ticker=',ticker,'W-test, and P-value')
print(stats.shapiro(ret.ret))
print(stats.anderson(ret.ret))

