# -*- coding: utf-8 -*-
"""
  Name     : c05_50_appendix_B.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

def APR2Rm(APR1,m1,m2):
    """Objective: convert one APR to another Rm
            APR1: annual percentage rate
            m1: compounding frequency
            m2: effective period rate with this compounding
            
            Formula used: Rm=(1+APR1/m1)**(m1/m2)-1
            
            Example #1>>>APR2Rm(0.1,2,4)
                      0.02469507659595993
    """
    return (1+APR/m1)**(m1/m2)-1

def APR2APR(APR1,m1,m2):
    """Objective: convert one APR to another Rm
            APR1: annual percentage rate
            m1: compounding frequency
            m2: effective period rate with this compounding
            
      Formula used: Rm=(1+APR1/m1)**(m1/m2)-1
    
       Example #1>>>APR2APR(0.1,2,4)
              0.09878030638383972
    """
    result=m2*((1+APR/m1)**(m1/m2)-1)
    return(result)

def APR2Rc(APR,m):
    return m*log(1+APR/m)

def Rc2Rm(Rc,m):
    return exp(Rc/m)-1

def Rc2APR(Rc,m):
    return m*(exp(Rc/m)-1)

