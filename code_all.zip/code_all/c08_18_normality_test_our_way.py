# -*- coding: utf-8 -*-
"""
  Name     : c08_18_normality_test_our_way.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import numpy as np
from scipy import stats 
np.random.seed(12345)
mean=0.1
std=0.2
n=5000
ret=np.random.normal(loc=0,scale=std,size=n)
alpha=0.05 # confidence level
Tcritical=abs(stats.t.ppf(alpha,df=n-1))
stdErr=ret.std()/np.sqrt(n)
target=0   # H0:   mean = target
Tvalue=abs((ret.mean()-target)/stdErr)
print(f"Tvalue={Tvalue}, and Tcritical={Tcritical}")
if(Tvalue>Tcritical):
    print("reject H0, i.e., returns don't follow a normal distribution.")
else:
    print("Accept H0, i.e., yes, returns follow a normal distribution.")

