
"""
  Name     : c11_20_VaR_500shares_WMT.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""
import numpy as np
import pandas as pd
import yfinance as yf
from scipy.stats import norm

#
ticker='WMT'            # input 1
n_shares=500            # input 2
confidence_level=0.99   # input 3
begdate="2012-1-1"      # input 5
enddate="2016-12-31"    # input 6
#
z=norm.ppf(confidence_level) 
df=yf.download(ticker,begdate,enddate)
ret =pd.DataFrame(df["Adj Close"].pct_change()).dropna()
ret.columns=["ret"]
#
position=n_shares*df.Close.iloc[-1] 
std=ret.ret.std()
#
VaR=position*z*std
print("Holding=",position, "VaR=", round(VaR,4), "tomorrow")








