# -*- coding: utf-8 -*-
"""
  Name     : c07_24_yfinance_download.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import yfinance as yf
ticker="ibm"
df=yf.download(ticker)
