# -*- coding: utf-8 -*-
"""
  Name     : c07_86_LPSD_function.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

def LPSD_f(returns,Rm):
    """Rm: a benchmark return
    """
    import numpy as np
    y=returns[returns<Rm] 
    total=0.0
    m=len(y)
    for r in y:
        total+=(r-Rm)**2
    #
    var=total/(m-1)
    LPSD=round(np.sqrt(var),5)
    return(LPSD)

import pandas as pd
annualRiskFree=0.01
path="http://datayyy.com/data_pickle/"
infile=path+"ibmMonthly.pkl"
df=pd.read_pickle(infile)
df["ret"]=df["Adj Close"].pct_change()
rf=annualRiskFree/12
LPSD=LPSD_f(df.ret,rf)
print(f"LPAD={LPSD}")
