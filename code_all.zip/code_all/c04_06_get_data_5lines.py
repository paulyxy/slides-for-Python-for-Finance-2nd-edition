# -*- coding: utf-8 -*-
"""
  Name     : c04_08_get_data_5lines.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import datetime    
import yfinance as yf

begdate = "1962-11-1"
enddate = "2016-11=7=
df =yf.download("IBM", begdate, enddate)
