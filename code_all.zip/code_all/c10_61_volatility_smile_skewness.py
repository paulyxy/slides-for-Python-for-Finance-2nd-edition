# -*- coding: utf-8 -*-
"""
  Name     : c10_61_volatility_smile_skewness.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""
import numpy as np
import datetime
import pandas as pd
import yfinance as yf
from scipy import stats 
from math import log,exp,sqrt 
import matplotlib.pyplot as plt
#
# Step 1: input area
#infile="http://datayyy.com/data_pickle/callsFeb2014.pkl"
#infile="c://temp/callsFeb2014.pkl"
infile="c://temp/calls23dec2022.pickle"
ticker='IBM'
r=0.0003 # estimate
begdate="2018-1-1"    # this is arbitrary 
enddate="2022-12-5"  # Dec 2022     February 2014
enddate2=datetime.date(2022,12,5)
# Step 2: define a function 
def implied_vol_call_min(S,X,T,r,c): 
  
    implied_vol=1.0
    min_value=1000
    for i in range(10000): 
        sigma=0.0001*(i+1)
        d1=(log(S/X)+(r+sigma*sigma/2.)*T)/(sigma*sqrt(T)) 
        d2 = d1-sigma*sqrt(T)
        c2=S*stats.norm.cdf(d1)-X*exp(-r*T)*stats.norm.cdf(d2) 
        abs_diff=abs(c2-c)
        if abs_diff<min_value: 
            min_value=abs_diff 
            implied_vol=sigma 
            k=i
    return(implied_vol)

# Step 3: get call option data 
calls=pd.read_pickle(infile)

#exp_date0=int('20'+calls.Symbol[0][len(ticker):9]) # find expiring date
exp_date0=int('20'+calls["Contract Name"][len(ticker)][3:9])

#p = getData(ticker, begdate,enddate,asobject=True, adjusted=True)

df=yf.download(ticker, begdate, enddate)
p=df.Close
#p=df.Close
#p=p0[-1]

#s=p.close[-1] # get current stock price 
#s=p[-1]
s=p.iloc[-1]
x
y=int(exp_date0/10000)
m=int(exp_date0/100)-y*100
d=exp_date0-y*10000-m*100
exp_date=datetime.date(y,m,d) # get exact expiring date 
T=(exp_date-enddate2).days/252.0 # T in years

# Step 4: run a loop to estimate the implied volatility 
n=len(calls.Strike) # number of strike

strike=[] # initialization
implied_vol=[] # initialization
call2=[] # initialization
x_old=0 # used when we choose the first strike 
#for i in range(n):
for i in np.arange(0,n):
    x=calls.Strike[i]
    c=(calls.Bid[i]+calls.Ask[i])/2.0
    if c >0:
        print(f"i={i} and c= {c}")
        if x!=x_old:
            vol=implied_vol_call_min(s,x,T,r,c)
            strike.append(x)
            implied_vol.append(vol)
            call2.append(c)
            print(x,c,vol)
            x_old=x
# Step 5: draw a smile 
plt.title('Skewness smile (skew)') 
plt.xlabel('Exercise Price') 
plt.ylabel('Implied Volatility')
plt.plot(strike,implied_vol,'o')
plt.show()






