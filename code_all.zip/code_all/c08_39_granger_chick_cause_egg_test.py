# -*- coding: utf-8 -*-
"""
  Name     : c08_39_granger_chick_cause_egg_test.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import pandas as pd
import statsmodels.api as sm
infile="http://datayyy.com/data_pickle/chickEgg.pickle"
df=pd.read_pickle(infile)
df["chicken_lag1"]=df.chicken.shift(1)
df["chicken_lag2"]=df.chicken.shift(2)
df["chicken_lag3"]=df.chicken.shift(3)
df["egg_lag1"]=df.egg.shift(1)
df["egg_lag2"]=df.egg.shift(2)
df["egg_lag3"]=df.egg.shift(3)
pd.set_option('display.max_columns',None)  
df.head()
df=df.dropna()

y=df["egg"]
x=df[["egg_lag1","egg_lag2","egg_lag3"]]
x=sm.add_constant(x)
results=sm.OLS(y,x).fit()
print(results.summary())


y=df["egg"]
x=df[["egg_lag1","egg_lag2","egg_lag3","chicken_lag1","chicken_lag2","chicken_lag3"]]
x=sm.add_constant(x)
results=sm.OLS(y,x).fit()
print(results.summary())
