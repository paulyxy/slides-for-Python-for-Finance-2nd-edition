# -*- coding: utf-8 -*-
"""
  Name     : c02_17_p4f310_download_unzip_import.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

from zipfile import ZipFile
from download import download
#
infile="http://datayyy.com/p4f/code/p4f310.zip"
outfile="aa.zip"
download(infile,outfile)

with ZipFile(outfile, "r") as zObject:
    zObject.extract("p4f310.pyc", path=".")
    
import p4f310 as p4f
