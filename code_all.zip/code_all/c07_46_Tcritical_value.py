# -*- coding: utf-8 -*-
"""
  Name     : c07_46_Tcritical_value.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import scipy.stats as stats
df=473
alpha=0.05
tCritical=stats.t.ppf(alpha,alpha,df)
print(tCritical)
-1.1404359422183676e+19


zCritical=stats.norm.ppf(alpha)
print(zCritical)
-1.6448536269514729
