# -*- coding: utf-8 -*-
"""
  Name     : c08_30_aucorrelation_tsa_acf.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import statsmodels.api as sm
import yfinance as yf
df=yf.download("ibm")
ret=df["Adj Close"].pct_change().dropna()
#calculate autocorrelations
result=sm.tsa.acf(ret)

