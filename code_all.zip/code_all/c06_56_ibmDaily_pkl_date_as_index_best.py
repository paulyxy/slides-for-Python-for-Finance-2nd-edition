# -*- coding: utf-8 -*-
"""
  Name     : c06_56_ibmDaily_pkl_date_as_index_best.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import pandas as pd
import datetime
df=pd.read_csv("c://temp/ibmDaily.csv")
dd=[]
for a in df["Date"]:
    d=pd.to_datetime(a,format="%Y-%m-%d").date()
    #print(d)
    dd.append(d)
#
df.index=dd
del df["Date"]
    
df.to_pickle("c://temp/ibmDaily.pkl")
