"""
"""
  Name     : c09_39_end_Of_chapter_problem_update_yanMonthly.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import pandas as pd
x=pd.read_pickle('c:/temp/yanMonthly.pkl')
print(x.head(2))
print(x.tail(3))



