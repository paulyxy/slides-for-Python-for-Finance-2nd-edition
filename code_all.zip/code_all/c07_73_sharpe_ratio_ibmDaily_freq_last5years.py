# -*- coding: utf-8 -*-
"""
  Name     : c07_73_sharpe_ratio_ibmDaily_freq_last5years.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import pandas as pd
import yfinance as yf
ticker="ibm"
df=yf.download(ticker)
df["ret"]=df["Adj Close"].pct_change()
df.shape # Out[53]: (15639, 7)
df2=df.tail(1260)  # 262 *5
df2.shape          # (1260, 7)
#
infile="http://datayyy.com/data_pickle/ff3daily.pkl"
ff3=pd.read_pickle(infile)
df3=df2.merge(ff3,left_on=df2.index,right_on=ff3.index,how="inner")
df3.shape # Out[61]: (1227, 12)
#
meanRet=round(df3.ret.mean(),5)
std    =round(df3.ret.std(),5)
meanRf =round(df3.RF.mean(),5)
sharpe =round((meanRet-meanRf)/std,5)
#
print(f"ticker is {ticker}, mean={meanRet},std={std}, and meanRf={meanRf}")
print(f"Sharpe Ratio of {ticker}={sharpe}")
