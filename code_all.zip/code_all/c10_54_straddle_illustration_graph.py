# -*- coding: utf-8 -*-
"""
  Name     : c10_54_straddle_illustration_graph.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import numpy as np
import matplotlib.pyplot as plt 
#
sT = np.arange(30,80,5)
x=50
c=2
p=1
straddle=(abs(sT-x)+sT-x)/2-c + (abs(x-sT)+x-sT)/2-p 
plt.plot(sT,straddle)






