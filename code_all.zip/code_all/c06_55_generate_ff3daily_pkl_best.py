"""
"""
  Name     : c06_55_generate_ff3daily_pkl_best.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import pandas as pd
import datetime
df=pd.read_csv("c://temp/ff3daily.csv",skiprows=5,header=None)
df.columns=["Date","MKT_RF","SMB","HML","RF"]
dd=[]
for a in df["Date"]:
    d=pd.to_datetime(a,format="%Y%m%d").date()
    #print(d)
    dd.append(d)
#

df = df.set_index(pd.DatetimeIndex(dd))

df.index=dd

df = df.set_index('Datetime')


del df["Date"]

df=df/100
df.to_pickle("c://temp/ff3.pkl")
