# -*- coding: utf-8 -*-
"""
  Name     : c05_02_EAR_from_semiAnnual.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

EAR=(1+0.08/2)**2-1

print(EAR)

EAR2=(1+0.079/4)**4-1

print(EAR2)
