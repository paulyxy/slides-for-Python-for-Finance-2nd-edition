"""
"""
  Name     : c10_48_data_case.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import pandas as pd
x=pd.read_pickle("c:/temp/businessCycle.pkl")
print(x.head())
print(x.tail())
