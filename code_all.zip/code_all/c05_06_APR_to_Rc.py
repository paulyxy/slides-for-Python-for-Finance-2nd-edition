# -*- coding: utf-8 -*-
"""
  Name     : c05_06_APR_to_Rc.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

from math import log
a=2*log(1+0.0234/2)


print(a)


def APR2Rc(APR,m):
    return m*log(1+APR/m)

b=APR2Rc(0.0234,2)
print(b)
