# -*- coding: utf-8 -*-
"""
  Name     : c09_54_yanMonthly_dataset_p329.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import pandas as pd
infile="http://datayyy.com/data_pickle/yanMonthly.pkl"
df=pd.read_pickle(infile)
df.shape
df.head()
