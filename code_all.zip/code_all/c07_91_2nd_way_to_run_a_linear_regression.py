# -*- coding: utf-8 -*-
"""
  Name     : c07_91_2nd_way_to_run_a_linear_regression.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import numpy as np
import scipy.stats as stats
rng = np.random.default_rng()
x = rng.random(10)
alpha=3
beta=1.2
y = alpha + beta*x + rng.random(10)
#   
target=0
T_intercept=(results.intercept-target)/results.intercept_stderr
T_slope=(results.slope-target)/results.stderr
results=stats.linregress(x, y)
print(f"intercept = {results.intercept} and its Tvalue={T_intercept}")
print(f"slope = {results.slope} and its T_value={T_slope}")
