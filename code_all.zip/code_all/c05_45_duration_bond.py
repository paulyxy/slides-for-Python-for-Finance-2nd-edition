"""
  Name     : c05_45_duration_bond.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

def bondPrice(year,fv,rate,couponRate,freq):
    import numpy_financial as npf
    bondPrice=npf.pv(rate/freq,year*freq,fv*couponRate/freq,fv)
    return(bondPrice)

# pv(rate, nper, pmt, fv=0, when='end')

def Duration (year,fv,rate,couponRate,freq):
    import numpy_financial as npf
    n=year*freq
    coupon=fv*couponRate/freq
    B=bondPrice(year,fv,rate,couponRate,freq)
    D=0 
    for i in range(1,n+1):
        t=i/freq
        pv=npf.pv(rate/freq,i,0,coupon)
        w=pv/B
        D+=w*t
        if i==n:
            pv=npf.pv(rate/freq,i,0,fv)
            w=pv/B
            D+=w*t
            #print(w)
    return round(D,2),round(B,2)

Duration(5,100,0.1,0.1,1)

Duration(5,1000,0.1,0.1,1)
