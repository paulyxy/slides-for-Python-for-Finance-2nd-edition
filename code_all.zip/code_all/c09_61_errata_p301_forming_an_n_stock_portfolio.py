# -*- coding: utf-8 -*-
"""
  Name     : c09_61_errata_p301_forming_an_n_stock_portfolio.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

#Errata p301


import pandas as pd
import yfinance as yf

tickers=['IBM','dell','wmt','^GSPC']
df=yf.download(tickers[0])




for ticker in tickers:
print ticker
x = pd.read_csv(path2.replace('ttt',ticker),usecols=[0,6],index_
col=0)
x.columns=[ticker]
final=pd.merge(final,x,left_index=True,right_index=True)
