# -*- coding: utf-8 -*-
"""
  Name     : c05_07_Rc2APR_function.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

from math import log,exp

def Rc2APR(Rc,m):
    return m*(exp(Rc/m)-1)

APR=Rc2APR(0.02,2)
print(APR)
