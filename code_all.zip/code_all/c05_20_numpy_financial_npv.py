# -*- coding: utf-8 -*-
"""
  Name     : c05_20_numpy_financial_npv.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""


import numpy_financial as npf 
dividends=[1.80,2.07,2.277,2.48193,2.680,2.7877]
R=0.182
g=0.03
npv=npf.npv(R,dividends[:-1])*(1+R)
print(npv)

pv=npf.pv(R,5,0,2.7877/(R-g))
print(pv)
