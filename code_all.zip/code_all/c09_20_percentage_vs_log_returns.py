# -*- coding: utf-8 -*-
"""
  Name     : c09_20_percentage_vs_log_returns.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""


from math import exp, log
R=0.1
logRet=log(R+1)
print(f"R={R} and logRet={logRet}")


R2=exp(logRet)-1
print(f"logRet={logRet} and R2={R2}")



