# -*- coding: utf-8 -*-
"""
  Name     : c07_84_why.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""


from sklearn import linear_model
model = linear_model.LinearRegression()
x=[[0, 0], [1, 1], [2, 2]]
hel
model.fit([[0, 0], [1, 1], [2, 2]], [0, 1, 2])
model.coef_


data=[[0, 0], [1, 1], [2, 2]], [0, 1, 2]
