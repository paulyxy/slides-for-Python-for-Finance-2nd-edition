# -*- coding: utf-8 -*-
"""
  Name     : c08_27_test_equal_vars_Method_1.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""
import numpy as np
import pandas as pd
import scipy.stats as stats

infile="http://datayyy.com/data_csv/sleep.csv"
df=pd.read_csv(infile)
#
group1=df[df.group==1]
group2=df[df.group==2]
var1=round(group1.extra.var(),4) # Out[203]: 3.200555555555556
var2=round(group2.extra.var(),4) # Out[202]: 4.0089999999999995
Fvalue=round(max(var1,var2)/min(var1,var2),4)
df1=group1.shape[0]-1  
df2=group2.shape[0]-1  
alpha=0.05
Fcritical=round(stats.f.ppf(1-alpha,df1,df2),4)

print(f"var1={var1},var2={var2}")
print(f"Fvalue={Fvalue},Fcritical={Fcritical}")
if(Fvalue>Fcritical):
    print("Reject H0: var1=var2")
else:
    print("Accept H0: var1 = var2")
