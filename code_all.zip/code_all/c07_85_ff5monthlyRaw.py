# -*- coding: utf-8 -*-
"""
  Name     : c07_85_ff5monthlyRaw.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import datetime
import pandas as pd
df=pd.read_csv("c://temp/ff5monthly.csv",skiprows=4,header=None)
df.columns=["DATE","MKT_RF","SMB","HML","RMW","CMA","RF"]
df.to_pickle("c://temp/ff5monthlyRaw.pickle")
