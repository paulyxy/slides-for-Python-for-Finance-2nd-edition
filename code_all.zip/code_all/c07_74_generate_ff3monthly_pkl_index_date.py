# -*- coding: utf-8 -*-
"""
  Name     : c07_74_generate_ff3monthly_pkl_index_date.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""
import datetime
import pandas as pd
df=pd.read_csv("c://temp/ff3monthly.csv",skiprows=4,header=None)
df.columns=["Date0","MKT_RF","SMB","HML","RF"]


df['Date'] = pd.to_datetime(df['Date0'],format="%Y%m")
df = df.set_index(pd.DatetimeIndex(df["Date"]))
#
df = df.drop(['Date0','Date'], axis=1)
df=df/100
df.to_pickle("c://temp/ff3monthly.pkl")
