# -*- coding: utf-8 -*-
"""
  Name     : c08_43_Benford_law.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import numpy as np
from math import log
a=np.arange(1,10)
for i in a:
    prob=round(log((i+1)/i),3)
    print(f"i={i} and prob={prob}")
