# -*- coding: utf-8 -*-
"""
  Name     : c08_07_errata_p248.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import yfinance as yf
df=yf.download("ibm",start="2013-1-1",end="2013-11-9")
df["ret"]=df["Adj Close"].pct_change()
df.head()
