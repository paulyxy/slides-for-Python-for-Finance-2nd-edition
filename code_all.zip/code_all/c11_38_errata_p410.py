# -*- coding: utf-8 -*-
"""
  Name     : c11_38_errata_p410.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import pandas as pd
import yfinance as yf
#
# Step 1: input area
tickers=('IBM','WMT','C') # tickers
begdate="2012-1-1"     # beginning date 
enddate="2016-12-31"   # ending date
weight=(0.2,0.5,0.3) # weights
confidence_level=0.99 # confidence level 
position=5e6 # total value
#
z=norm.ppf(confidence_level) 
# Step 2: define a function
def ret_f(ticker,begdate,enddte):
    df=yf.download(ticker,begdate,enddate)
    ret=df["Adj Close"].pct_change()
    d0=df.index[1:]
    df2=pd.DataFrame(ret,index=d0,columns=[ticker])
    return(df2)

retIBM=ret_f("ibm",begdate,enddate)
