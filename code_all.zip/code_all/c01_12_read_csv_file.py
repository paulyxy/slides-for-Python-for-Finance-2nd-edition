# -*- coding: utf-8 -*-
"""
  Name     : c01_12_read_csv_file.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""
import pandas as pd
x=pd.read_csv("c:/temp/ibm.csv")
