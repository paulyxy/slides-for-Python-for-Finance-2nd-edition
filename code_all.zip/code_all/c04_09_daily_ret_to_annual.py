# -*- coding: utf-8 -*-
"""
  Name     : c04_11_daily_ret_to_annual.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import pandas as pd
import yfinance as yf
from math import exp,log
#
ticker='IBM'
begdate="1980-1-1"
enddate="2012-12-31"
df = yf.download(ticker, begdate, enddate)
#
aa=pd.DataFrame(df["Adj Close"].pct_change().dropna()+1)
aa["yyyy"]=aa.index.year
aa.columns=["retPlus1","yyyy"]
retAnnual=aa.retPlus1.groupby(aa.yyyy).prod()-1
print(aa.head())
print(retAnnual.head())

