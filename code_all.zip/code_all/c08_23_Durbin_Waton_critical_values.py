# -*- coding: utf-8 -*-
"""
  Name     : c08_23_Durbin_Waton_critical_values.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import pandas as pd
path="http://datayyy.com/data_csv/"
infile=path+"durbin_watson_critical_values.csv"
df=pd.read_csv(infile)
