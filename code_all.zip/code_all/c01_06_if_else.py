# -*- coding: utf-8 -*-
"""
  Name     : c01_06_if_else.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import numpy as np
cashFlows=np.array([-100,50,40,30])
for cash in cashFlows:
    print(cash)


for cash in cashFlows:
    if cash >0:
        print(cash)
    else:
        print(f"this is negative:{cash}")
