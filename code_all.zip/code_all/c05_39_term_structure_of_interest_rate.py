# -*- coding: utf-8 -*-
"""
  Name     : c05_39_term_structure_of_interest_rate.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import matplotlib.pyplot as plt
time=[3/12,6/12,2,3,5,10,30]
rate=[0.47,0.6,1.18,1.53,2,2.53,3.12]
plt.title("Term Structure of Interest Rate ")
plt.xlabel("Time ")
plt.ylabel("Risk-free rate (%)")
plt.plot(time,rate)
#
plt.show()
