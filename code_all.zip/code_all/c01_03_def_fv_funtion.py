# -*- coding: utf-8 -*-
"""
  Name     : c01_03_def_fv_funtion.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

def fv_f(pv,r,n):
    return pv*(1+r)**n
#
fv=fv_f(100,0.1,2)
print(fv)
