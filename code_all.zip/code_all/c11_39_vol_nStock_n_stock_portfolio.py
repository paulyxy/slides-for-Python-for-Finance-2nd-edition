# -*- coding: utf-8 -*-
"""
  Name     : c11_39_vol_nStock_n_stock_portfolio.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""
import numpy as np
from math import sqrt

def vol_portfolio(ret_matrix,weights):
    m=ret_matrix.shape[1]
    m2=len(weights)
    if(m!=m2):
        print("# of stocks  not = # of weights!")
    else:
        cov=np.cov(ret_matrix.T)
        final=0
        n=np.arange(0,m)
        for i in n:
            for j in n:
                final+=weights[i]*weights[j]*cov[i,j]
    stdP=sqrt(final)
    return(stdP)
    
 

