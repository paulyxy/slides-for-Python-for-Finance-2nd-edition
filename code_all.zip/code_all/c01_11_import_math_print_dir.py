# -*- coding: utf-8 -*-
"""
  Name     : c01_11_import_math_print_dir.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""
import math
x=dir(math)
print(x)
