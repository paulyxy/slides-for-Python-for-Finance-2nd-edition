# -*- coding: utf-8 -*-
"""
  Name     : c05_43_effectiveRate_givenAPR1_twoFreq.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

def effectiveRate(APR1,freq1,freq2):
    EAR2=(1+APR1/freq1)**(freq1/freq2)-1
    return(EAR2)


