# -*- coding: utf-8 -*-
"""
  Name     : c08_42_benford_law_formula.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import numpy as np
from math import log10
a=np.arange(1,10)
for i in a:
    prob=round(log10((i+1)/i),3)
    print(f"i={i} and prob={prob}")
