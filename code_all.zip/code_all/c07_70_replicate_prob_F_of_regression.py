# -*- coding: utf-8 -*-
"""
  Name     : c07_70_replicate_prob_F_of_regression.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import scipy.stats as stats
df1=3
df2=473
Fvalue=3.466
#
left_tail=stats.f.cdf(Fvalue,df1,df2)
print(f"left_tail={left_tail}")
right_tail=1-left_tail
print(f"right_tail={right_tail}")
