# -*- coding: utf-8 -*-
"""
  Name     : c08_12_F_density_distribution_graph.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""
import numpy as np
import scipy.stats as stats
import matplotlib.pyplot as plt
x=np.arange(0,3,0.1)
df1=10
df2=12
y=stats.f.pdf(x,df1,df2)
plt.plot(x,y)
plt.title("F-distribution: probability density distribution")
plt.xlabel("Our X-values")
plt.ylabel("Density function")
plot.show()
