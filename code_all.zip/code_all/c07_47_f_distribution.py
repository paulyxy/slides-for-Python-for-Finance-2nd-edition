# -*- coding: utf-8 -*-
"""
  Name     : c07_47_f_distribution.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import numpy as np
import scipy.stats as stats
import matplotlib.pyplot as plt
#
x=np.arange(0,4,0.1)
df1=20
df2=10
y=stats.f.pdf(x,df1,df2)
plt.title("F-distribution")
plt.xlabel("X-values")
plt.ylabel("F density ditribution")
plt.plot(x,y)
plt.show()

