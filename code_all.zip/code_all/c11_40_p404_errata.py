# -*- coding: utf-8 -*-
"""
  Name     : c11_40_p404_errata.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""


import numpy as np
import pandas as pd
import yfinance as yf
from scipy.stats import stats,norm
#
ticker='WMT' # input 1
n_shares=500 # input 2
confidence_level=0.99 # input 3
begdate="2000-1-1"    # input 4
enddate="2016-12-31"  # input 5
#
# Method I: based on the first two moments
z=abs(norm.ppf(1-confidence_level)) 
df=yf.download(ticker,begdate,enddate)
ret = df["Adj Close"].pct_change()

