# -*- coding: utf-8 -*-
"""
  Name     : c08_03_normal_random_sample_stdErr_marginOfError.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import numpy as np
import scipy.stats as stats
mean=0.15
std=0.03
n=300
x=np.random.normal(mean,std,n)
#
alpha=0.05  # confidence level 
stdErr=std/np.sqrt(n)
z=stats.norm.ppf(alpha)
marginOfErr=abs(z)*stdErr
lowerBound=mean2-marginOfErr
upperBound=mean2+marginOfErr
print(f"LowerBound={lowerBound} and upperBound={upperBound}")
