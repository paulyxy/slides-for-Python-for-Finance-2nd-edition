"""
"""
  Name     : c11_12_second_way_to_calculate_10dayVaR.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""
import numpy as np
import pandas as pd 
import yfinance as yf
from scipy.stats import norm

# input area
ticker='WMT'            # input 1
n_shares=50             # input 2
confidence_level=0.99   # input 3
nDays=10                # input 4
begdate="2012-1-1"      # input 5
enddate="2016-12-31"    # input 6
#
z=norm.ppf(confidence_level) 
df =yf.download(ticker, begdate, enddate)
logret = np.log(df["Adj Close"].pct_change()+1)
logret2=pd.DataFrame(logret[1:])
# method 2: calculate 10 day returns 
ddate=[]
#d0=x.date
for i in np.arange(0,np.size(logret2)): 
    ddate.append(int(i/nDays))
#
logret2.index=ddate
logret2.columns=["logRet2"]
retNdays=np.exp(logret2.logRet2.groupby(logret2.index).sum())-1
print(retNdays.head())
position=n_shares*df.Close[-1] 
VaR=position*z*np.std(retNdays)
print("Holding=",position, "VaR=", round(VaR,4), "in ", nDays, "Days")
