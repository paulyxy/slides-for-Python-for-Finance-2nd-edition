# -*- coding: utf-8 -*-
"""
  Name     : c05_34_duration_2simpleCashFlows.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import numpy_financial as npf
cf=100
r=0.10
n1=1
n2=2
pv1=-npf.pv(r,n1,0,cf)
pv2=-npf.pv(r,n2,0,cf)
w1=pv1/(pv1+pv2)
d=w1*n1+(1-w1)*n2
print(d)
