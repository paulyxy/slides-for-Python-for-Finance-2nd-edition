# -*- coding: utf-8 -*-
"""
  Name     : c08_28_test_equal_vars.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""
import numpy as np
import pandas as pd
import scipy.stats as stats

infile="http://datayyy.com/data_csv/sleep.csv"
df=pd.read_csv(infile)
#
group1=df[df.group==1]
group2=df[df.group==2]
group1.extra.var() # Out[203]: 3.200555555555556
group2.extra.var() # Out[202]: 4.0089999999999995
stats.levene(group1.extra,group2.extra)
