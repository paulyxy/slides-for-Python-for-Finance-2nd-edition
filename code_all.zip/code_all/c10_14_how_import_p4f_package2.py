"""
  Name     : c10_14_how_import_p4f_package2.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""
# -*- coding: utf-8 -*-

import zipfile
from download import download

infile="http://datayyy.com/p4f/code/p4f311.zip"
outfile="p4f.zip"
download(infile,outfile)

with zipfile.ZipFile(outfile,'r') as zip_ref:
    zip_ref.extractall(".")
     
import p4f311 as p4f 
print(dir(p4f))


