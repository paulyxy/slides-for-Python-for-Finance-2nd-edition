# -*- coding: utf-8 -*-
"""
  Name     : c02_12_location_of_yfinance.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""


import importlib

importlib.util.find_spec("yfinance")

Out[31]: ModuleSpec(name='yfinance', loader=<_frozen_importlib_external.SourceFileLoader object at 0x0000020A2BB31250>, origin='C:\\Users\\pauly\\anaconda3\\Lib\\site-packages\\yfinance\\__init__.py', submodule_search_locations=['C:\\Users\\pauly\\anaconda3\\Lib\\site-packages\\yfinance'])
