"""
  Name     : c08_22_p247_errata.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""
import pandas as pd
url='http://datayyy.com/data_csv/ibmDaily.csv' 
x=pd.read_csv(url,index_col=0,parse_dates=True)
print(x.head())
