# -*- coding: utf-8 -*-
"""
  Name     : c04_08_get_data_5lines.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""


import yfinance as yf
#
ticker="IBM"
begdate="2015-1-1"
enddate="2015-11-9"
df =yf.download(ticker,begdate,enddate)
ret=df["Adj Close"].pct_change().dropna()
