# -*- coding: utf-8 -*-
"""
  Name     : c07_43_merge_02_stock.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

pv=100
fv=pv*(1+0.1)**20

print(fv)
