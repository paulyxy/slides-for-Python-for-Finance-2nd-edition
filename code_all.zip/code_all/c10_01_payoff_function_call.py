"""
"""
  Name     : c10_01_payoff_function_call.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

def payoff_call(sT,x):
    return (sT-x+abs(sT-x))/2
