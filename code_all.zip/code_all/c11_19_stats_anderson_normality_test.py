# -*- coding: utf-8 -*-
"""
  Name     : c11_19_stats_anderson_normality_test.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import scipy.stats as stats
help(stats.anderson)
