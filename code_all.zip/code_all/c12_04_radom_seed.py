# -*- coding: utf-8 -*-
"""
  Name     : c12_04_radom_seed.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import numpy.random as random
random.seed(12345)
x=random.standard_normal(size=10)
print(x)
