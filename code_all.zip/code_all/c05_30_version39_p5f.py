# -*- coding: utf-8 -*-
"""
  Name     : c05_30_version39_p5f.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""


from download import download
path="http://datayyy.com/code_py/"
file="p4f39.pyc"
infile=path+file
outfile='p4f.pyc'
download(infile,outfile,replace=True)
import p4f 
