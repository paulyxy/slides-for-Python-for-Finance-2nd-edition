# -*- coding: utf-8 -*-
"""
  Name     : c05_15_duration_with_help.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

from numpy import exp

def duration(t,cash_flow,y):
    """Objective: calculate the duration of a set cash flows
    Parameters
    ----------
            t : a set of time  periods
    cash_flow : set of cash flows 
            y : yield or discount rate 
        
   Example :>>>t=[1,2,3,4,5]
            >>>cash=[100,200,300,200,230]
            >>>rate=0.1
            >>>d=duration(t,cash,rate)
            >>>print(d)
            3.0911342716137167
            
    Example #2:>>>t=[1,2,3]
               >>>cash=[0,0,10]
               >>>rate=0.1
               >>>print(duration(t,cash,rate))
               3.0000000000000004
    """
    n=len(t)
    B,D=0,0
    for i in range(n):
        B+=cash_flow[i]*exp(-y*t[i])
        D+=t[i]*cash_flow[i]*exp(-y*t[i])
    return(D/B)


