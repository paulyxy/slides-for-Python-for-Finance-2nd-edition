# -*- coding: utf-8 -*-
"""
  Name     : c06_53_linear_add_random.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import numpy as np
from scipy import stats 
import matplotlib.pyplot as plt
np.random.seed(12456)
alpha=1.0
beta=0.8
n=120
x=np.arange(n)
y=alpha+beta*x+np.random.rand(n)
plt.plot(y,x)
plt.show()



(beta, alpha, r_value, p_value, std_err) = stats.linregress(y,x) 
print(alpha,beta) 
print("R-squared=", r_value**2)
print("p-value =", p_value)



