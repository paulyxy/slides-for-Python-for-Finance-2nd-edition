# -*- coding: utf-8 -*-
"""
  Name     : c08_44_normality_test_our_way.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import pandas as pd
path="http://datayyy.com/data_pickle/"
infile=path+"usGDPquarterly.pkl"
GDP=pd.read_pickle(infile)
infile2=path+"ff3monthly.pkl"
ff3=pd.read_pickle(infile2)
print(GDP.head())
print(ff3.head())
