"""
"""
  Name     : c11_11_VaR_500shares_IBM_tomorrow.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import yfinance as yf
from scipy.stats import norm
#
ticker='IBM'              # input 1
n_shares=1000             # input 2
confidence_level=0.99     # input 3
z=norm.ppf(1-confidence_level) 
df=yf.download(ticker)
ret = df["Adj Close"].pct_change().dropna()
position=round(n_shares*df.Close.iloc[-1],2)
std=ret.std()
VaR=round(position*z*std,2)
lastDay=df.index[-1].date()
print(f"Holding={position}, VaR={VaR} tomorrow.")
print(f"number of shares={n_shares}, today={lastDay}.")









