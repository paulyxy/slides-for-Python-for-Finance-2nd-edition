# -*- coding: utf-8 -*-
"""
  Name     : c04_07_first_one.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import yfinance as yf
df = yf.download("IBM", "2015-1-1", "2015-12-31")
print(df[0:5])




