# -*- coding: utf-8 -*-
"""
  Name     : c11_42_errata_p396.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import numpy as np
import pandas as pd
import yfinance as yf
from scipy.stats import norm
