# -*- coding: utf-8 -*-
"""
  Name     : c07_55_f_right_tail.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

import scipy.stats as stats
df1=20
df2=10
x=2
left_tail=stats.f.cdf(x,df1,df2)
print(f"left-tail={left_tail}")
print(f"right-tail={right_tail}")




