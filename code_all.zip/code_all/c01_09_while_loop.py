# -*- coding: utf-8 -*-
"""
  Name     : c01_09_while_loop.py
  Book     : Python for Finance (2nd ed.)
  Publisher: Packt Publishing Ltd. 
  Author   : Yuxing Yan
  Date     : 6/6/2017,3/19/2024
  email    : paulyxy@gmail.com
"""

i=1
while(i<10):
    print(i)
    i+=1
